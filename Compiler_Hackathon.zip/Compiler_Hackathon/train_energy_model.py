import os
import joblib
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split

X = np.array([
    [60, 16, 20, 20, 10, 10],
    [120, 64, 40, 40, 20, 20],
    [300, 128, 100, 100, 50, 50],
    [480, 256, 160, 160, 80, 80],
    [960, 512, 320, 320, 160, 160]
])

y = np.array([4.2, 10.8, 25.0, 42.0, 84.0])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = xgb.XGBRegressor(n_estimators=100, max_depth=4, learning_rate=0.1)
model.fit(X_train, y_train)

os.makedirs("model", exist_ok=True)
joblib.dump(model, "model/energy_model_advanced.pkl")
print("✅ Advanced model trained and saved!")