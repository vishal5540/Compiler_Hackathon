
from flask import Flask, render_template, request, jsonify
from ir.llvm_ir_gen import build_ir_from_real_matrices
from backend.memory_map import create_memory_map_from_matrices
from backend.isa_encoder import translate_ir_text_to_binary
from backend.optimizer_ai import suggest_optimizations
from backend.energy_predictor import predict_energy_and_bottlenecks
from backend.graph_data import get_instruction_stats
from backend.cpp_matrix_parser import parse_cpp_matrix
import numpy as np

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/compile', methods=['POST'])
def compile_code():
    try:
        data = request.json
        use_cpp = data.get("use_cpp", False)

        if use_cpp:
            A = parse_cpp_matrix(data.get("A_cpp", ""))
            B = parse_cpp_matrix(data.get("B_cpp", ""))
        else:
            A = data.get("A", [])
            B = data.get("B", [])

        A = np.array(A)
        B = np.array(B)

        if A.shape[1] != B.shape[0]:
            return jsonify({"error": "Matrix dimensions do not match for multiplication"}), 400

        C = np.dot(A, B).tolist()

        ir_module = build_ir_from_real_matrices(A, B, C)
        ir_str = str(ir_module)

        binary = translate_ir_text_to_binary(ir_str)
        memory_map = create_memory_map_from_matrices(A, B, C)

        tips = suggest_optimizations(ir_str, A.shape[0], A.shape[1], B.shape[1])
        energy, ai_insight_tips = predict_energy_and_bottlenecks(ir_str, A.shape[0] * A.shape[1] * B.shape[1])
        tips += ai_insight_tips

        instr_stats = get_instruction_stats(ir_str)

        return jsonify({
            "ir": ir_str,
            "binary": [f"{word:06X}" for word in binary],
            "memory_map": memory_map,
            "ai_tips": tips,
            "energy": energy,
            "instr_stats": instr_stats,
            "output_matrix": C
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
