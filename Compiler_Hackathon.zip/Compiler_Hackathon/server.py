from flask import Flask, render_template, request, jsonify
from ir.llvm_ir_gen import build_matrix_mul_ir
from backend.memory_map import create_memory_map
from backend.isa_encoder import translate_ir_text_to_binary
from backend.optimizer_ai import suggest_optimizations
from backend.energy_predictor import predict_energy_and_bottlenecks
from backend.graph_data import get_instruction_stats

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/compile', methods=['POST'])
def compile_code():
    try:
        data = request.json
        M = int(data.get("M", 2))
        N = int(data.get("N", 2))
        P = int(data.get("P", 2))

        ir_module = build_matrix_mul_ir(M, N, P)
        ir_str = str(ir_module)

        binary = translate_ir_text_to_binary(ir_str)

        memory_map = create_memory_map(M, N, P)

        tips = suggest_optimizations(ir_str, M, N, P)

        energy, ai_insight_tips = predict_energy_and_bottlenecks(ir_str, M * N * P)
        tips += ai_insight_tips

        instr_stats = get_instruction_stats(ir_str)

        return jsonify({
            "ir": ir_str,
            "binary": [f"{word:06X}" for word in binary],
            "memory_map": memory_map,
            "ai_tips": tips,
            "energy": energy,
            "instr_stats": instr_stats
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)