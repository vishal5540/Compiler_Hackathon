def encode_instruction(op: str, dest: str = "", src1: str = "", src2: str = "") -> int:
    op_map = {
        'LOAD':  0x01,
        'STORE': 0x02,
        'MUL':   0x03,
        'ADD':   0x04,
        'PROG':  0x10,
        'EXE':   0x20,
        'END':   0x30,
    }
    opcode = op_map.get(op.upper(), 0xFF)

    instruction = (opcode << 16) | 0x0000
    return instruction

def translate_ir_text_to_binary(ir_code: str):
    binary = []
    for line in ir_code.splitlines():
        line = line.strip().lower()
        if any(op in line for op in ['load', 'store', 'mul', 'add']):
            for op in ['load', 'store', 'mul', 'add']:
                if op in line:
                    encoded = encode_instruction(op)
                    binary.append(encoded)
    binary.append(encode_instruction('END'))
    return binary