def create_memory_map(M, N, P):
    mapping = {}
    addr = 0x1000
    for m in ['A', 'B', 'C']:
        rows = M if m == 'A' else (N if m == 'B' else M)
        cols = N if m == 'A' else (P if m != 'C' else P)
        for i in range(rows):
            for j in range(cols):
                mapping[f"{m}[{i}][{j}]"] = addr
                addr += 1
    return mapping