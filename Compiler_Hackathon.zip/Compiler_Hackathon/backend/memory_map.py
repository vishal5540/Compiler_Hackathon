
def create_memory_map_from_matrices(A, B, C, base_addr=0x1000, word_size=4):
    memory_map = {}
    addr = base_addr

    # Matrix A memory mapping
    for i in range(len(A)):
        for j in range(len(A[0])):
            memory_map[f"A[{i}][{j}]"] = addr
            addr += word_size

    # Matrix B memory mapping
    for i in range(len(B)):
        for j in range(len(B[0])):
            memory_map[f"B[{i}][{j}]"] = addr
            addr += word_size

    # Matrix C memory mapping
    for i in range(len(C)):
        for j in range(len(C[0])):
            memory_map[f"C[{i}][{j}]"] = addr
            addr += word_size

    return memory_map
