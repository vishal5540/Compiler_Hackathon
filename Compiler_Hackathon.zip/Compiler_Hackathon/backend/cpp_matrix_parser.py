
import re

def parse_cpp_matrix(code_str):
    """
    Parses a C++ style 2D matrix declaration and returns a Python list of lists.
    Example input: 'int A[2][2] = {{1, 2}, {3, 4}};'
    Returns: [[1, 2], [3, 4]]
    """
    # Remove whitespace and newlines for easier pattern matching
    code_str = code_str.replace('\n', '').replace(' ', '')
    match = re.search(r'={{(.*)}};', code_str)
    if not match:
        return []

    inner = match.group(1)
    # Convert {{1,2},{3,4}} to [[1,2],[3,4]]
    inner = inner.replace('{', '[').replace('}', ']')
    try:
        parsed = eval(inner)
        return parsed
    except:
        return []
