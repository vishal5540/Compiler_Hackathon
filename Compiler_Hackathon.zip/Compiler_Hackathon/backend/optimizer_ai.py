def suggest_optimizations(ir_code: str, M: int, N: int, P: int):
    tips = []
    matrix_size = M * N * P
    ir = ir_code.lower()

    if "mul" in ir and "add" in ir:
        tips.append("[Performance] 🔄 Consider loop unrolling on 'k' to reduce MAC latency.")

    if matrix_size > 128:
        tips.append("[Memory] 📦 Matrix too large for fast cache — suggest blocking or tiling.")

    if "load" in ir and ir.count("load") > 50:
        tips.append("[Memory] 🧠 Too many loads — consider reusing loaded values in registers.")

    if matrix_size > 512:
        tips.append("[Energy] ⚡ Estimate indicates high cost — reduce dimensions or tile smartly.")

    if "store" in ir and ir.count("store") > 40:
        tips.append("[Memory] 💾 Too many stores — check if results can be fused or deferred.")

    if M == N == P:
        tips.append("[Balance] 🎯 Square matrices — consider symmetric optimization paths.")

    if not tips:
        tips.append("✅ Code looks optimized for this size!")

    return tips