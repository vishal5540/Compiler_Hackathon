def get_instruction_stats(ir_code: str):
    ir = ir_code.lower()
    return {
        "load": ir.count("load"),
        "store": ir.count("store"),
        "mul": ir.count("mul"),
        "add": ir.count("add"),
        "total": len(ir.splitlines())
    }