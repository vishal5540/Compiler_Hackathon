import joblib
import numpy as np

model = joblib.load("model/energy_model_advanced.pkl")

def extract_features_from_ir(ir_code, matrix_size):
    ir = ir_code.lower()
    total_instr = ir.count('\n')
    mul = ir.count('mul')
    add = ir.count('add')
    load = ir.count('load')
    store = ir.count('store')
    return [total_instr, matrix_size, mul, add, load, store]

def predict_energy_and_bottlenecks(ir_code, matrix_size):
    features = np.array([extract_features_from_ir(ir_code, matrix_size)])
    energy = model.predict(features)[0]

    tips = []
    if features[0][2] > 100:
        tips.append("🧠 High MAC usage — consider loop unrolling.")
    if features[0][3] > 100:
        tips.append("📐 Try loop fusion or tiling.")
    if features[0][4] > 100:
        tips.append("💾 Optimize memory loads — use local caching.")

    return round(float(energy), 2), tips