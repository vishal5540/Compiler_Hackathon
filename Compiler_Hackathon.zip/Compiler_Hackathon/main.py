from ir.llvm_ir_gen import build_matrix_mul_ir
from backend.isa_encoder import translate_ir_text_to_binary
from backend.memory_map import create_memory_map

if __name__ == "__main__":
    print("🔧 LLVM-PIM Compiler\n")

    llvm_ir = build_matrix_mul_ir()
    print("=== LLVM IR ===\n")
    print(llvm_ir)

    binary = translate_ir_text_to_binary(str(llvm_ir))
    print("\n=== PIM ISA Binary ===\n")
    for b in binary:
        print(f"{b:06X}")

    print("\n=== Memory Map ===")
    mapping = create_memory_map()
    for k, v in mapping.items():
        print(f"{k} -> 0x{v:X}")