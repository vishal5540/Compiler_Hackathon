
from llvmlite import ir

def build_ir_from_real_matrices(A, B, C):
    M, N = len(A), len(A[0])
    P = len(B[0])

    module = ir.Module(name="matrix_mul_module")
    int32 = ir.IntType(32)

    # Define function signature: void multiply([M x [N x i32]]*, [N x [P x i32]]*, [M x [P x i32]]*)
    matA_ty = ir.PointerType(ir.ArrayType(ir.ArrayType(int32, N), M))
    matB_ty = ir.PointerType(ir.ArrayType(ir.ArrayType(int32, P), N))
    matC_ty = ir.PointerType(ir.ArrayType(ir.ArrayType(int32, P), M))

    func_ty = ir.FunctionType(ir.VoidType(), [matA_ty, matB_ty, matC_ty])
    func = ir.Function(module, func_ty, name="multiply")
    block = func.append_basic_block(name="entry")
    builder = ir.IRBuilder(block)

    ptrA, ptrB, ptrC = func.args

    for i in range(M):
        for j in range(P):
            c_tmp = builder.alloca(int32, name=f"ctmp_{i}_{j}")
            builder.store(int32(0), c_tmp)

            for k in range(N):
                a_ptr = builder.gep(ptrA, [ir.Constant(int32, 0), ir.Constant(int32, i), ir.Constant(int32, k)])
                b_ptr = builder.gep(ptrB, [ir.Constant(int32, 0), ir.Constant(int32, k), ir.Constant(int32, j)])
                a_val = builder.load(a_ptr)
                b_val = builder.load(b_ptr)
                mul = builder.mul(a_val, b_val)
                acc = builder.load(c_tmp)
                sum_ = builder.add(acc, mul)
                builder.store(sum_, c_tmp)

            result = builder.load(c_tmp)
            c_ptr = builder.gep(ptrC, [ir.Constant(int32, 0), ir.Constant(int32, i), ir.Constant(int32, j)])
            builder.store(result, c_ptr)

    builder.ret_void()
    return module
