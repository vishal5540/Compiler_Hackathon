from llvmlite import ir

def build_matrix_mul_ir(M, N, P):
    module = ir.Module(name="pim_matrix_module")
    int32 = ir.IntType(32)

    A_type = ir.ArrayType(ir.ArrayType(int32, N), M)
    B_type = ir.ArrayType(ir.ArrayType(int32, P), N)
    C_type = ir.ArrayType(ir.ArrayType(int32, P), M)

    func_type = ir.FunctionType(ir.VoidType(), [A_type.as_pointer(), B_type.as_pointer(), C_type.as_pointer()])
    func = ir.Function(module, func_type, name="multiply")
    A, B, C = func.args
    A.name, B.name, C.name = "A", "B", "C"

    entry_block = func.append_basic_block(name="entry")
    builder = ir.IRBuilder(entry_block)

    for i in range(M):
        for j in range(P):
            c_tmp = builder.alloca(int32, name=f"ctmp_{i}_{j}")
            builder.store(ir.Constant(int32, 0), c_tmp)
            for k in range(N):
                a_ptr = builder.gep(A, [ir.Constant(int32, 0), ir.Constant(int32, i), ir.Constant(int32, k)])
                b_ptr = builder.gep(B, [ir.Constant(int32, 0), ir.Constant(int32, k), ir.Constant(int32, j)])
                a_val = builder.load(a_ptr)
                b_val = builder.load(b_ptr)
                mul = builder.mul(a_val, b_val)
                prev = builder.load(c_tmp)
                new_sum = builder.add(prev, mul)
                builder.store(new_sum, c_tmp)
            final_val = builder.load(c_tmp)
            c_ptr = builder.gep(C, [ir.Constant(int32, 0), ir.Constant(int32, i), ir.Constant(int32, j)])
            builder.store(final_val, c_ptr)

    builder.ret_void()
    return module